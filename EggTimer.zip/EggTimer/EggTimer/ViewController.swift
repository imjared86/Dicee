//
//  ViewController.swift
//  EggTimer
//
//  Created by Jared Chen on 08/07/2023.
//

import UIKit

class ViewController: UIViewController {
//    let softTime = 5
//    let mediumTime = 8
//    let hardTime = 12
    
    @IBOutlet weak var msgLabel: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    //Dictionary
    let eggTimes = ["Soft": 300, "Medium": 480, "Hard": 720]
    var secondsRemaining = 0
    var totalTime = 0
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        progressBar.progress = 0.0
    }

    @IBAction func hardnessSelected(_ sender: UIButton) {
        timer.invalidate()
        progressBar.progress = 0.0
        
        let hardness = sender.currentTitle!
        //print(hardness) - Print Optional value
        //print(hardness!) - Print String value
        
        msgLabel.text = "\(hardness) Egg Selected"
        
//        var timeSpent = 0
        
        //IF-Else statement
//        if hardness == "Soft" {
//            totalTime = softTime
//        }else if hardness == "Medium" {
//            totalTime = mediumTime
//        }else{
//            totalTime = hardTime
//        }
        
        //Swith statement
//        switch hardness {
//        case "Soft":
//            totalTime = softTime
//        case "Medium":
//            totalTime = mediumTime
//        default:
//            totalTime = hardTime
//        }
        
        totalTime = eggTimes[hardness]!
        print("Time spent to cook \(hardness) egg is \(totalTime) minutes." )
        secondsRemaining = totalTime
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if secondsRemaining > 0 {
            print("\(secondsRemaining) seconds...")
            secondsRemaining -= 1
            progressBar.progress = Float(totalTime - secondsRemaining) / Float(totalTime)
        }else{
            msgLabel.text = "Done!"
            progressBar.progress = 1.0
        }
    }
}
